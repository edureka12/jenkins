package code

// TxStatus TODO:
type TxStatus struct {
}

// Block TODO:
type Block struct {
}
