/*
 * Copyright (c) 2019, Baidu.com, Inc. All Rights Reserved.
 */

package main

import (
	"github.com/spf13/cobra"
)

// TxCommand tx cmd
type TxCommand struct {
}

// NewTxCommand new tx cmd
func NewTxCommand(cli *Cli) *cobra.Command {
	cmd := &cobra.Command{
		Use:   "tx",
		Short: "Operate tx command, query",
	}
	cmd.AddCommand(NewTxQueryCommand(cli))
	return cmd
}

func init() {
	AddCommand(NewTxCommand)
}
