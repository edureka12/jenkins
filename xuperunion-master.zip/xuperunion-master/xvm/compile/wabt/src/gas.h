#ifndef WABT_GAS_WRITER_H_
#define WABT_GAS_WRITER_H_

namespace wabt {
class Module;
void WriteModuleGas(Module* module);

}

#endif